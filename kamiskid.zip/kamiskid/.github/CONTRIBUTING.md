
You are free to clone, modify KAMI Blue and make pull requests as you wish. 

Before contributing please see the [Code of Conduct](https://blue.bella.wtf/codeofconduct)

See [Support](https://blue.bella.wtf/support) for help.

See this [this](https://blue.bella.wtf/contributing
) page for building instructions and how to setup a workspace
