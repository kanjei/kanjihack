package me.zeroeightsix.kami.event.events;

import me.zeroeightsix.kami.event.KamiEvent;

public class PlayerTravelEvent extends KamiEvent {}
