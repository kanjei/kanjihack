package me.zeroeightsix.kami.module.modules.player

import me.zeroeightsix.kami.module.Module

/**
 * @author THEREALWWEFAN231
 * @see me.zeroeightsix.kami.mixin.client.MixinBlockLiquid
 * Thanks to THEREALWWEFAN231 for the Mixin
 */
@Module.Info(
        name = "LiquidInteract",
        category = Module.Category.PLAYER,
        description = "Place blocks on liquid!"
)
class LiquidInteract : Module()