package me.zeroeightsix.kami.gui.kami.theme.kami;

import me.zeroeightsix.kami.gui.kami.component.Chat;
import me.zeroeightsix.kami.gui.rgui.render.AbstractComponentUI;

/**
 * Created by 086 on 2/08/2017.
 */
public class RootChatUI extends AbstractComponentUI<Chat> {
}
