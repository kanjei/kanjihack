package me.zeroeightsix.kami.gui.rgui.component.listen;

/**
 * Created by 086 on 26/06/2017.
 */
public interface RenderListener {
    public void onPreRender();

    public void onPostRender();
}
