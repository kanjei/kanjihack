package me.zeroeightsix.kami.event.events;

import me.zeroeightsix.kami.event.KamiEvent;

public class ServerConnectedEvent extends KamiEvent {
    public ServerConnectedEvent() {
        super();
    }
}
