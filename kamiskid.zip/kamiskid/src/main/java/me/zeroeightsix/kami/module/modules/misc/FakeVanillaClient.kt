package me.zeroeightsix.kami.module.modules.misc

import me.zeroeightsix.kami.module.Module

/**
 * Created by 086 on 9/04/2018.
 */
@Module.Info(
        name = "FakeVanillaClient",
        description = "Fakes a modless client when connecting",
        category = Module.Category.MISC
)
class FakeVanillaClient : Module()