package me.zeroeightsix.kami.gui.rgui.layout;

import me.zeroeightsix.kami.gui.rgui.component.container.Container;

/**
 * Created by 086 on 5/08/2017.
 */
public class UselessLayout implements Layout {
    @Override
    public void organiseContainer(Container container) {
        // Do absolutely nothing
    }


}
