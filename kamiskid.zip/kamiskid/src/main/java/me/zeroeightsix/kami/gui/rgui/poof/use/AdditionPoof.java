package me.zeroeightsix.kami.gui.rgui.poof.use;

import me.zeroeightsix.kami.gui.rgui.component.Component;
import me.zeroeightsix.kami.gui.rgui.poof.PoofInfo;

/**
 * Created by 086 on 21/07/2017.
 */
public abstract class AdditionPoof<T extends Component, S extends PoofInfo> extends Poof<T, S> {
}
